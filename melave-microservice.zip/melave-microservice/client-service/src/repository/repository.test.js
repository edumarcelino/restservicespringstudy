const test = require('tape');
const repository = require('./repository');
 
function runTests(){
 
    var id = null;
 
    test('Repository GetAllLavaJatos', (t) => {
        repository.getAllLavaJatos((err, lavajatos) => {
            if(lavajatos && lavajatos.length > 0) id = lavajatos[0]._id;
            
            t.assert(!err && lavajatos && lavajatos.length > 0, "All Lava Jatos Returned");
            t.end();
        });
    })
    
    test('Repository GetLavaJatoById', (t) => {
        if(!id) {
            t.assert(false, "LavaJato by Id Returned");
            t.end();
            return;
        }
 
        repository.getLavaJatoById(id, (err, lavajatos) => {
            t.assert(!err && lavajatos, "LavaJato by Id Returned");
            t.end();
        });
    })
 
 
    test('Repository Disconnect', (t) => {
        t.assert(repository.disconnect(), "Disconnect Ok");
        t.end();
    })
}
 
module.exports = { runTests }