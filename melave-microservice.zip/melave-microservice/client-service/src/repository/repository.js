const mongodb = require("../config/mongodb");
 
function getAllLavaJatos(callback){
    mongodb.connect((err, db) => {
        db.collection("lavajatos").find().toArray(callback);
    })
}
 
function getLavaJatoById(id, callback){
    mongodb.connect((err, db) => {
        db.collection("lavajatos").findOne({_id: require("mongodb").ObjectId(id)}, callback);
    });
}
 
 
function disconnect(){
    return mongodb.disconnect();
}
 
module.exports = { getAllMovies, getMovieById, disconnect }