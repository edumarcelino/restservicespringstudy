module.exports = (app, repository) => {
 
  app.get('/lavajatos', (req, res, next) => {
    repository.getAllLavaJatos((err, lavajatos) => {
      if(err) return next(err);
      res.json(lavajatos);
    });
  })
 
  app.get('/lavajatos/:id', (req, res, next) => {
    repository.getLavaJatoById(req.params.id, (err, lavajato) => {
      if(err) return next(err);
      res.json(lavajato)
    });
  })
}