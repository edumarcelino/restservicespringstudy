const test = require('tape');
const supertest = require('supertest');
const lavajatos = require('./lavajatos');
const server = require("../server/server");
const repository = require("../repository/repository");
 
function runTests(){
 
    var app = null;
    server.start(lavajatos, repository, (err, app) => { 
        var id = null;
        test('GET /lavajatos', (t) => {
            supertest(app)
                .get('/lavajatos')
                .expect('Content-Type', /json/)
                .expect(200)
                .end((err, res) =>{
                    if(res.body && res.body.length > 0) id = res.body[0]._id;
                    t.error(err, 'No errors')
                    t.assert(res.body && res.body.length > 0, "All LavaJatos returned")
                    t.end()  
                })
        })
        
        test('GET /lavajatos/:id', (t) => {
            if(!id) {
                t.assert(false, "LavaJato by Id Returned");
                t.end();
                return;
            }
 
            supertest(app)
                .get('/lavajatos/' + id)
                .expect('Content-Type', /json/)
                .expect(200)
                .end((err, res) =>{
                    t.error(err, 'No errors')
                    t.assert(res.body, "LavaJatos By Id returned")
                    t.end()  
                })
        })
 
        
 
        server.stop();
     })
}
 
module.exports = { runTests }