require("dotenv-safe").load();
const lavajatos = require('./api/lavajatos');
const server = require("./server/server");
const repository = require("./repository/repository");
 
server.start(lavajatos, repository, (err, app) => { 
    console.log("just started");
});