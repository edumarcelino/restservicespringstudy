// Carregando os pacotes necessarios
var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var passport = require('passport');
var all_routes = require('express-list-endpoints');

var authController = require('./controllers/auth');
var userController = require('./controllers/user');

// Controladores das entidades
var lavajatoController = require('./controllers/lavajato');
var servicoController = require('./controllers/servico');


// Esquema do Login
//var Client = require('./models/auth/client');
//var Code = require('./models/auth/code');
//var Token = require('./models/auth/token');
var User = require('./models/auth/user');

// Seta a criação de index
mongoose.set('useCreateIndex', true)

// Conecta com o mongoDB melave
mongoose.connect('mongodb://localhost:27017/melave',  { useNewUrlParser: true });

// Cria a aplicação Express
var app = express();

// Usa o pacote body-parser no aplicativo
app.use(bodyParser.urlencoded({
  extended: true
}));

// Usa o pacote passport na aplicacao
app.use(passport.initialize());

// Cria o roteamento pelo Express
var router = express.Router();


// Define a porta do servidor
var port = process.env.PORT || 3000;


// Registra todas as rotas com os endpoints /api
app.use('/api', router);


//
//  LAVA JATO
//


// Cria os endpoints para /lavajatos
router.route('/lavajatos')
  .post(authController.isAuthenticated, lavajatoController.postLavaJatos)
  .get(authController.isAuthenticated, lavajatoController.getLavaJatos);

// Cria os endpoints para /lavajatos/:lavajato_id
router.route('/lavajatos/:lavajato_id')
  .get(authController.isAuthenticated, lavajatoController.getLavaJato)
  .put(authController.isAuthenticated, lavajatoController.putLavaJato)
  .delete(authController.isAuthenticated, lavajatoController.deleteLavaJato);


//
//  SERVICES
//


// Cria os endpoints para /services
router.route('/servicos')
  .post(authController.isAuthenticated, servicoController.postServicos)
  .get(authController.isAuthenticated, servicoController.getServicos);

// Cria os endpoints para /services/:service_id
router.route('/servicos/:servico_id')
  .get(authController.isAuthenticated, servicoController.getServico)
  .put(authController.isAuthenticated, servicoController.getServico)
  .delete(authController.isAuthenticated, servicoController.deleteServico);



// Create endpoint handlers for /users
router.route('/users')
  .post(userController.postUsers)
  .get(authController.isAuthenticated, userController.getUsers);

//
//  INICIALIZA O SERVIDOR NA PORTA ESPECIFICADA
//


// Inicia o servidor



app.listen(port);
console.log('Servidor iniciado na porta: ' + port);
console.log(router);


