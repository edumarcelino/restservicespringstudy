// Carrega o Pacote CarWash
var Servico = require('../models/servico');


// Create endpoint /api/servico for POSTS
exports.postServicos = function(req, res) {
  
  // Cria uma nova instancia do Servico Model
  var servico = new Servico();

  // Seta as propriedade para um Servico para inserir
  servico.nome = req.body.nome;
  servico.urlImage = req.body.urlImage;
  servico.ativo = req.body.ativo;
  servico.uf = req.body.uf;
  servico.municipio = req.body.municipio;
  

  // Salva o Servico e checa por erros
  servico.save(function(err) {
    if (err)
      res.send(err);

    res.json({ message: 'Servico adicionado !', data: servico });
  });
};


// Cria o endpoint /api/servicos for GET
exports.getServicos = function(req, res) {
  Servico.find(  function(err, servicos) {
    if (err)
      res.send(err);
    res.json(servicos);
  });
};

// Cria o endpoint /api/servicos/:servico_id for GET
exports.getServico = function(req, res) {
  // Usa o modelo de Servico para encontrar um servico
  Servico.findById( { _id: req.params.servico_id } , function(err, servico) {
    if (err)
      res.send(err);

    res.json(servico);
  });
};

// Cria o endpoint /api/servicos/:servico_id para atualizacao via PUT
exports.putServico = function(req, res) {
  
	Servico.updateOne({ _id: req.params.servico_id }, 
		{ 
			// Atualiza os atributos do carwash
    	nome : req.body.nome,
      urlImage : req.body.urlImage,
      ativo : req.body.ativo,
    }, 
		function(err, num, raw) {
			if (err)
      			res.send(err);
		res.json({ message: num + ' atualizados' });
  	});
};

// Cria o endpoint para  /api/servicos/:servico_id para deletar usando o verbo DELETE
exports.deleteServico = function(req, res) {

  // Usa o modelo do Service para encontrar e remover
  Servico.remove({ _id: req.params.service_id }, function(err) {
    if (err)
      res.send(err);

    res.json({ message: 'Servico Removido!' });
  });
};
