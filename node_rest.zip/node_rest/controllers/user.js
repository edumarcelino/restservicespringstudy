// Load required packages
var User = require('../models/auth/user');

// Create endpoint /api/users for POST
exports.postUsers = function(req, res) {
  var user = new User({
    username: req.body.username,
    password: req.body.password,
    tipoUsuario : req.body.tipoUsuario
  });

  user.save(function(err) {
    if (err)
      res.send(err);

    res.json({ message: 'Novo usuário adicionado' });
  });
};

// Create endpoint /api/users for GET
exports.getUsers = function(req, res) {
  User.find(function(err, users) {
    if (err)
      res.send(err);

    res.json(users);
  });
};