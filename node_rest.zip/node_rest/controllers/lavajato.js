// Carrega o Pacote Lava Jato
var LavaJato = require('../models/lavajato');


// Create endpoint /api/carwash for POSTS
exports.postLavaJatos = function(req, res) {
  
  // Cria uma nova instancia do Lava Jato Model
  var lavajato = new LavaJato();

  // Seta as propriedade para um lavajato para inserir
  lavajato.nome = req.body.nome;
  lavajato.nomeFantasia = req.body.nomeFantasia;
  lavajato.tipoPrestador = req.body.tipoPrestador;
  lavajato.cnpj = req.body.cnpj;
  lavajato.nomeProprietario = req.body.nomeProprietario;
  lavajato.cpfProprietario = req.body.cpfProprietario;
  lavajato.endereco = req.body.endereco;
  lavajato.email = req.body.email;
  lavajato.instagram = req.body.instagram;
  lavajato.facebook = req.body.facebook;
  lavajato.twitter = req.body.twitter;
  lavajato.complemento = req.body.complemento;
  lavajato.numero = req.body.numero;
  lavajato.bairro = req.body.bairro;
  lavajato.cidade = req.body.cidade;
  lavajato.uf = req.body.uf;
  lavajato.ufDescricao = req.body.ufDescricao;
  lavajato.geo = req.body.geo;
  lavajato.pais = req.body.pais;
  lavajato.status = req.body.status;
  lavajato.userId = req.user._id;

  // Salva o LavaJato e checa por erros
  lavajato.save(function(err) {
    if (err)
      res.send(err);

    res.json({ message: 'Lava Jato adicionado !', data: lavajato });
  });
};


// Cria o endpoint /api/lavajatos for GET
exports.getLavaJatos = function(req, res) {
  
  LavaJato.find( { userId: req.user._id } , function(err, lavajatos) {
    if (err)
      res.send(err);

    res.json(lavajatos);
  });
};

// Cria o endpoint /api/lavajatos/:lavajato_id for GET
exports.getLavaJato = function(req, res) {

  LavaJato.findById( { userId: req.user._id, _id: req.params.lavajato_id } , function(err, lavajato) {
    if (err)
      res.send(err);

    res.json(lavajato);
  });
};

// Create endpoint /api/lavajatos/:lavajato_id for PUT
exports.putLavaJato = function(req, res) {

	LavaJato.updateOne({ userId: req.user._id, _id: req.params.lavajato_id }, 
		{ 
			// Atualiza os atributos do lavajato
    		nome : req.body.nome,
		    nomeFantasia : req.body.nomeFantasia,
		    tipoPrestador : req.body.tipoPrestador,
		    cnpj : req.body.cnpj,
		    nomeProprietario : req.body.nomeProprietario,
		    cpfProprietario : req.body.cpfProprietario,
		    endereco : req.body.endereco,
		    email : req.body.email,
		    instagram : req.body.instagram,
		    facebook : req.body.facebook,
		    twitter : req.body.twitter,
		    complemento : req.body.complemento,
		    numero : req.body.numero,
		    bairro : req.body.bairro,
		    cidade : req.body.cidade,
		    uf : req.body.uf,
		    ufDescricao : req.body.ufDescricao,
        geo : req.body.geo,
		    pais : req.body.pais,
		    status : req.body.status
		}, 
		function(err, num, raw) {
			if (err)
      			res.send(err);
		res.json({ message: num + ' atualizados' });
  	});
};

// Create endpoint /api/lavajato/:lavajato_id for DELETE
exports.deleteLavaJato = function(req, res) {

  // Usa o modelo do LavaJato para encontrar e remover
  LavaJato.remove({ userId: req.user._id, _id: req.params.lavajato_id }, function(err) {
    if (err)
      res.send(err);

    res.json({ message: 'LavaJato Removed!' });
  });
};
