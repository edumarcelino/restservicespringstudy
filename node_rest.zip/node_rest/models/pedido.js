// Load required packages
var mongoose = require('mongoose');
var validator = require('validator');

// Load required packages
var Service = require('../models/service');
var User = require('../models/auth/user');
var CarWash = require('../models/carwash');


// Define our beer schema
var PedidoSchema   = new mongoose.Schema({
  
  _id:{ 
    type: mongoose.Schema.Types.ObjectId, 
    auto: true                           
  }
  
});

// Exporta o modelo mongoose
module.exports = mongoose.model('Pedido', PedidoSchema);