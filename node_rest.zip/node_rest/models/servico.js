// Load required packages
var mongoose = require('mongoose');
var validator = require('validator');


// Load required packages
var LavaJato = require('../models/lavajato');

// Define o Schema Servico
var ServicoSchema   = new mongoose.Schema({
    
    _id:{ 
    	type: mongoose.Schema.Types.ObjectId, 
    	auto: true                           
  	},
  	nome: {
  		type: String,
  		required: true
  	},
    urlImage: {
      type: String,
      required: true
    },
  	ativo: {
  		type: Boolean,
  		default: true
  	},
    uf: {
      type: String,
      required: true,
      enum: ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO']
    },
    municipio: {
      type: String,
      required: true
    },
    dataCadastro: {
    	type: Date,
    	default: Date.now
  	}
});

// Exporta o modelo mongoose
module.exports = mongoose.model('Servico', ServicoSchema);