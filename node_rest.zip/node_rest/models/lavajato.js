// Load required packages
var mongoose = require('mongoose');
var validator = require('validator');

// Carrega o modelo Servico
var Servico = require('../models/servico');
var HorarioFuncionamento = require('../models/horariofuncionamento');


// Schema do lava jato
var LavaJatoSchema   = new mongoose.Schema({
  
  _id:{ 
    type: mongoose.Schema.Types.ObjectId, 
    auto: true                           
  },
  nome: {
    type: String,
    required: true
  },
  nomeFantasia: {
    type: String,
    required: true
  },
  tipoPrestador: {
    type: String,
    //required: true,
    enum: ['PF','PJ']
  },
  cnpj: {
    type: String
  },
  nomeProprietario: {
    type: String,
    required: true
  },
  cpfProprietario: {
    type: String,
    required: true
  },
  endereco: {
    type: String,
    required: true
  },  
  email:{
    type:String,
    required: true,
    validate:{
      validator: validator.isEmail,
      message: '{VALUE} is not a valid email'
    }
  },
  instagram: {
    type: String
  },
  facebook: {
        type: String,
        validate: {
            validator: function(text) {
                return text.indexOf('https://www.facebook.com/') === 0;
            },
            message: 'Facebook must start with https://www.facebook.com/'
        }
  },
  twitter: {
        type: String,
        validate: {
            validator: function(text) {
                return text.indexOf('https://twitter.com/') === 0;
            },
            message: 'Twitter handle must start with https://twitter.com/'
        }
  },
  endereco: {
    type: String,
    required: true
  },          
  complemento: {
    type: String
  },
  numero: {
    type     : Number,
    required : true,
    validate : {
      validator : Number.isInteger,
      message   : '{VALUE} is not an integer value'
    }
  },
  bairro: {
    type: String,
    //required: true
  },
  cidade: {
    type: String,
    //required: true
  },             
  uf: {
    type: String,
    //required: true,
    enum: ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO']
  },
  geo: {
    type: [Number],
    //required: true,
    index: '2d'
  },
  pais: {
    type: String,
    default: 'Brasil'
  },
  status: {
    type: String,
    default: 'aberto'
  },
  userId: {
    type: String
  },
  pathImagens: 
  [{
    type: String
  }],
  servicos: 
  [
    {
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'Service'}
  ],
  horarioFuncionamento: 
  [
    {
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'HorarioFuncionamento'}
  ],
  dataCadastro: {
    type: Date,
    default: Date.now
  }
});

// Exporta o modelo mongoose
module.exports = mongoose.model('LavaJato', LavaJatoSchema);