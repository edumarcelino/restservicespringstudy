// Load required packages
var mongoose = require('mongoose');
var validator = require('validator');


// Define o Schema de horario de funcionamento
var HorarioFuncionamentoSchema   = new mongoose.Schema({
    
    _id:{ 
    	type: mongoose.Schema.Types.ObjectId, 
    	auto: true                           
  	},
    diaSemana: {
      type: String,
      required: true,
      enum: ['Domingo', 'Segunda', 'Terca', 'Quarta', 'Quinta', 'Sexta', 'Sabado'] 
    },
  	horarioInicial:{
        type: Date,
        required: true
    },
    horarioFinal:{
        type: Date,
        required: true
    }
});

// Exporta o modelo mongoose
module.exports = mongoose.model('HorarioFuncionamento', HorarioFuncionamentoSchema);